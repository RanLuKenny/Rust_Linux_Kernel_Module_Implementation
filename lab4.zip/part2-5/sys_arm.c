long (* mycall_ptr) (int gpio, int is_input) = NULL;
EXPORT_SYMBOL(mycall_ptr);	

asmlinkage long sys_mycall(int gpio, int is_input)
{
	return mycall_ptr ? mycall_ptr(gpio, is_input) : -ENOSYS;
}

long (* mycall_ptr2) (unsigned offset, int enable) = NULL;
EXPORT_SYMBOL(mycall_ptr2);	

asmlinkage long sys_mycall2(unsigned offset, int enable)
{
	return mycall_ptr2 ? mycall_ptr2(offset, enable) : -ENOSYS;
}


static irq_handler_t px5_irq_handler(unsigned int irq, void *dev_id, struct pt_regs *regs){
   counter_value = get_count_cycle();
   printk("Interrupt takes place (counter value is %d)\n", counter_value);
   sys_mycall(17, 0);
   sys_mycall2(17, 1);
   return (irq_handler_t) IRQ_HANDLED;      
}


asmlinkage long sys_part2_ori(int mode, int gpio)
{  
	if (mode == 0){ 
		if (!gpio_is_valid(gpio)){
      			printk("invalid GPIO\n");
      			return -ENODEV;
		}
		gpio_request(49, "sysfs");
                gpio_export(49, true);
                tstart = get_count_cycle();
                sys_mycall(17, 0);
                sys_mycall2(17, 1);
	}
        else if (mode ==1){
                int suc_or_not;
                irqNumber = gpio_to_irq(49);
                printk("The gpio is mapped to IRQ: %d\n", irqNumber);
		suc_or_not = request_irq(irqNumber,     // result = 0 means success
			     	    (irq_handler_t) px5_irq_handler,
			     	    IRQF_TRIGGER_LOW,
			     	    "px5_gpio_handler",
			     	    NULL);
                //enable_irq(irqNumber);
                sys_mycall(17, 1);
		printk(" The interrupt request result is: %d\n", suc_or_not);
                return 0;
        }
	else if (mode == 2) 
	{
		free_irq(irqNumber, NULL);     
                gpio_unexport(49);
		gpio_free(49);
		printk("free gpio & irq\n");
                printk("The time from up to down is %d couner cycles\n",counter_value-tstart);
                return counter_value;
	}
}

asmlinkage long sys_part2(int mode, int gpio )
{
        if (mode == 0) {
             sys_part2_ori(0, gpio);
             sys_part2_ori(1, gpio);
        }
        else if (mode ==1){
             sys_part2_ori(2, gpio);
        }
}
