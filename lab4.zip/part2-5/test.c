 #include<stdio.h>
 #include<linux/kernel.h>
 #include <linux/module.h>
 int main()
 {
 while(1){
             lab4_part2(0, 49);
             lab4_part2(1, 49);
             //time_h_to_l_1 = time_h_to_l_2;
             //time_h_to_l_2 = lab4_part2(3, 49);
             time_h_to_l = lab4_part2(3, 49);
             //printk("The time from high to low is %d\n",time_h_to_l);
             if(time_h_to_l< threshold) printk("touched\n");
             else if(time_h_to_l> threshold) printk("released\n");

        }
        break;
 }
