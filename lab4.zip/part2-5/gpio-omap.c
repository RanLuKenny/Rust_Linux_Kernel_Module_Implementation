/*
 * Support functions for OMAP GPIO
 *
 * Copyright (C) 2003-2005 Nokia Corporation
 * Written by Juha Yrjölä <juha.yrjola@nokia.com>
 *
 * Copyright (C) 2009 Texas Instruments
 * Added OMAP4 support - Santosh Shilimkar <santosh.shilimkar@ti.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/interrupt.h>
#include <linux/syscore_ops.h>
#include <linux/err.h>
#include <linux/clk.h>
#include <linux/io.h>
#include <linux/device.h>
#include <linux/pm_runtime.h>
#include <linux/pm.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/gpio.h>
#include <linux/bitops.h>
#include <linux/ioport.h>
#include <linux/platform_data/gpio-omap.h>
#include <linux/kernel.h>
#include <linux/init.h>


//lab2 headers begin
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/version.h>
#include <linux/types.h>
#include <linux/kdev_t.h>
#include <linux/ioctl.h>

#include <linux/module.h>
#include <asm/uaccess.h>	// for put_user
#include <linux/slab.h>
#include <linux/init.h>
#include<linux/delay.h>
#include <linux/device.h>
#include <linux/cdev.h>


//lab2 headers end




#define OFF_MODE	1
#define OMAP4_GPIO_DEBOUNCINGTIME_MASK 0xFF

static LIST_HEAD(omap_gpio_list);

struct gpio_regs {
	u32 irqenable1;
	u32 irqenable2;
	u32 wake_en;
	u32 ctrl;
	u32 oe;
	u32 leveldetect0;
	u32 leveldetect1;
	u32 risingdetect;
	u32 fallingdetect;
	u32 dataout;
	u32 debounce;
	u32 debounce_en;
};

struct gpio_bank {
	struct list_head node;
	void __iomem *base;
	int irq;
	u32 non_wakeup_gpios;
	u32 enabled_non_wakeup_gpios;
	struct gpio_regs context;
	u32 saved_datain;
	u32 level_mask;
	u32 toggle_mask;
	raw_spinlock_t lock;
	raw_spinlock_t wa_lock;
	struct gpio_chip chip;
	struct clk *dbck;
	u32 mod_usage;
	u32 irq_usage;
	u32 dbck_enable_mask;
	bool dbck_enabled;
	struct device *dev;
	bool is_mpuio;
	bool dbck_flag;

	bool context_valid;
	int stride;
	u32 width;
	int context_loss_count;
	int power_mode;
	bool workaround_enabled;

	void (*set_dataout)(struct gpio_bank *bank, unsigned gpio, int enable);
	int (*get_context_loss_count)(struct device *dev);

	struct omap_gpio_reg_offs *regs;
};

#define GPIO_MOD_CTRL_BIT	BIT(0)

#define BANK_USED(bank) (bank->mod_usage || bank->irq_usage)
#define LINE_USED(line, offset) (line & (BIT(offset)))

static void omap_gpio_unmask_irq(struct irq_data *d);

static inline struct gpio_bank *omap_irq_data_get_bank(struct irq_data *d)
{
	struct gpio_chip *chip = irq_data_get_irq_chip_data(d);
	return container_of(chip, struct gpio_bank, chip);
}

static void omap_set_gpio_direction(struct gpio_bank *bank, int gpio,
				    int is_input)
{
	void __iomem *reg = bank->base;
	u32 l;

	reg += bank->regs->direction;
	l = readl_relaxed(reg);
	if (is_input)
		l |= BIT(gpio);
	else
		l &= ~(BIT(gpio));
	writel_relaxed(l, reg);
	bank->context.oe = l;
}


/* set data out value using dedicate set/clear register */
static void omap_set_gpio_dataout_reg(struct gpio_bank *bank, unsigned offset,
				      int enable)
{
	void __iomem *reg = bank->base;
	u32 l = BIT(offset);

	if (enable) {
		reg += bank->regs->set_dataout;
		bank->context.dataout |= l;
	} else {
		reg += bank->regs->clr_dataout;
		bank->context.dataout &= ~l;
	}

	writel_relaxed(l, reg);
}

/* set data out value using mask register */
static void omap_set_gpio_dataout_mask(struct gpio_bank *bank, unsigned offset,
				       int enable)
{
	void __iomem *reg = bank->base + bank->regs->dataout;
	u32 gpio_bit = BIT(offset);
	u32 l;

	l = readl_relaxed(reg);
	if (enable)
		l |= gpio_bit;
	else
		l &= ~gpio_bit;
	writel_relaxed(l, reg);
	bank->context.dataout = l;
}

static int omap_get_gpio_datain(struct gpio_bank *bank, int offset)
{
	void __iomem *reg = bank->base + bank->regs->datain;

	return (readl_relaxed(reg) & (BIT(offset))) != 0;
}

static int omap_get_gpio_dataout(struct gpio_bank *bank, int offset)
{
	void __iomem *reg = bank->base + bank->regs->dataout;

	return (readl_relaxed(reg) & (BIT(offset))) != 0;
}

static inline void omap_gpio_rmw(void __iomem *base, u32 reg, u32 mask, bool set)
{
	int l = readl_relaxed(base + reg);

	if (set)
		l |= mask;
	else
		l &= ~mask;

	writel_relaxed(l, base + reg);
}

static inline void omap_gpio_dbck_enable(struct gpio_bank *bank)
{
	if (bank->dbck_enable_mask && !bank->dbck_enabled) {
		clk_enable(bank->dbck);
		bank->dbck_enabled = true;

		writel_relaxed(bank->dbck_enable_mask,
			     bank->base + bank->regs->debounce_en);
	}
}

static inline void omap_gpio_dbck_disable(struct gpio_bank *bank)
{
	if (bank->dbck_enable_mask && bank->dbck_enabled) {
		/*
		 * Disable debounce before cutting it's clock. If debounce is
		 * enabled but the clock is not, GPIO module seems to be unable
		 * to detect events and generate interrupts at least on OMAP3.
		 */
		writel_relaxed(0, bank->base + bank->regs->debounce_en);

		clk_disable(bank->dbck);
		bank->dbck_enabled = false;
	}
}

/**
 * omap2_set_gpio_debounce - low level gpio debounce time
 * @bank: the gpio bank we're acting upon
 * @offset: the gpio number on this @bank
 * @debounce: debounce time to use
 *
 * OMAP's debounce time is in 31us steps
 *   <debounce time> = (GPIO_DEBOUNCINGTIME[7:0].DEBOUNCETIME + 1) x 31
 * so we need to convert and round up to the closest unit.
 */
static void omap2_set_gpio_debounce(struct gpio_bank *bank, unsigned offset,
				    unsigned debounce)
{
	void __iomem		*reg;
	u32			val;
	u32			l;
	bool			enable = !!debounce;

	if (!bank->dbck_flag)
		return;

	if (enable) {
		debounce = DIV_ROUND_UP(debounce, 31) - 1;
		debounce &= OMAP4_GPIO_DEBOUNCINGTIME_MASK;
	}

	l = BIT(offset);

	clk_enable(bank->dbck);
	reg = bank->base + bank->regs->debounce;
	writel_relaxed(debounce, reg);

	reg = bank->base + bank->regs->debounce_en;
	val = readl_relaxed(reg);

	if (enable)
		val |= l;
	else
		val &= ~l;
	bank->dbck_enable_mask = val;

	writel_relaxed(val, reg);
	clk_disable(bank->dbck);
	/*
	 * Enable debounce clock per module.
	 * This call is mandatory because in omap_gpio_request() when
	 * *_runtime_get_sync() is called,  _gpio_dbck_enable() within
	 * runtime callbck fails to turn on dbck because dbck_enable_mask
	 * used within _gpio_dbck_enable() is still not initialized at
	 * that point. Therefore we have to enable dbck here.
	 */
	omap_gpio_dbck_enable(bank);
	if (bank->dbck_enable_mask) {
		bank->context.debounce = debounce;
		bank->context.debounce_en = val;
	}
}

/**
 * omap_clear_gpio_debounce - clear debounce settings for a gpio
 * @bank: the gpio bank we're acting upon
 * @offset: the gpio number on this @bank
 *
 * If a gpio is using debounce, then clear the debounce enable bit and if
 * this is the only gpio in this bank using debounce, then clear the debounce
 * time too. The debounce clock will also be disabled when calling this function
 * if this is the only gpio in the bank using debounce.
 */
static void omap_clear_gpio_debounce(struct gpio_bank *bank, unsigned offset)
{
	u32 gpio_bit = BIT(offset);

	if (!bank->dbck_flag)
		return;

	if (!(bank->dbck_enable_mask & gpio_bit))
		return;

	bank->dbck_enable_mask &= ~gpio_bit;
	bank->context.debounce_en &= ~gpio_bit;
        writel_relaxed(bank->context.debounce_en,
		     bank->base + bank->regs->debounce_en);

	if (!bank->dbck_enable_mask) {
		bank->context.debounce = 0;
		writel_relaxed(bank->context.debounce, bank->base +
			     bank->regs->debounce);
		clk_disable(bank->dbck);
		bank->dbck_enabled = false;
	}
}

static inline void omap_set_gpio_trigger(struct gpio_bank *bank, int gpio,
						unsigned trigger)
{
	void __iomem *base = bank->base;
	u32 gpio_bit = BIT(gpio);

	omap_gpio_rmw(base, bank->regs->leveldetect0, gpio_bit,
		      trigger & IRQ_TYPE_LEVEL_LOW);
	omap_gpio_rmw(base, bank->regs->leveldetect1, gpio_bit,
		      trigger & IRQ_TYPE_LEVEL_HIGH);
	omap_gpio_rmw(base, bank->regs->risingdetect, gpio_bit,
		      trigger & IRQ_TYPE_EDGE_RISING);
	omap_gpio_rmw(base, bank->regs->fallingdetect, gpio_bit,
		      trigger & IRQ_TYPE_EDGE_FALLING);

	bank->context.leveldetect0 =
			readl_relaxed(bank->base + bank->regs->leveldetect0);
	bank->context.leveldetect1 =
			readl_relaxed(bank->base + bank->regs->leveldetect1);
	bank->context.risingdetect =
			readl_relaxed(bank->base + bank->regs->risingdetect);
	bank->context.fallingdetect =
			readl_relaxed(bank->base + bank->regs->fallingdetect);

	if (likely(!(bank->non_wakeup_gpios & gpio_bit))) {
		omap_gpio_rmw(base, bank->regs->wkup_en, gpio_bit, trigger != 0);
		bank->context.wake_en =
			readl_relaxed(bank->base + bank->regs->wkup_en);
	}

	/* This part needs to be executed always for OMAP{34xx, 44xx} */
	if (!bank->regs->irqctrl) {
		/* On omap24xx proceed only when valid GPIO bit is set */
		if (bank->non_wakeup_gpios) {
			if (!(bank->non_wakeup_gpios & gpio_bit))
				goto exit;
		}

		/*
		 * Log the edge gpio and manually trigger the IRQ
		 * after resume if the input level changes
		 * to avoid irq lost during PER RET/OFF mode
		 * Applies for omap2 non-wakeup gpio and all omap3 gpios
		 */
		if (trigger & IRQ_TYPE_EDGE_BOTH)
			bank->enabled_non_wakeup_gpios |= gpio_bit;
		else
			bank->enabled_non_wakeup_gpios &= ~gpio_bit;
	}

exit:
	bank->level_mask =
		readl_relaxed(bank->base + bank->regs->leveldetect0) |
		readl_relaxed(bank->base + bank->regs->leveldetect1);
}

#ifdef CONFIG_ARCH_OMAP1
/*
 * This only applies to chips that can't do both rising and falling edge
 * detection at once.  For all other chips, this function is a noop.
 */
static void omap_toggle_gpio_edge_triggering(struct gpio_bank *bank, int gpio)
{
	void __iomem *reg = bank->base;
	u32 l = 0;

	if (!bank->regs->irqctrl)
		return;

	reg += bank->regs->irqctrl;

	l = readl_relaxed(reg);
	if ((l >> gpio) & 1)
		l &= ~(BIT(gpio));
	else
		l |= BIT(gpio);

	writel_relaxed(l, reg);
}
#else
static void omap_toggle_gpio_edge_triggering(struct gpio_bank *bank, int gpio) {}
#endif

static int omap_set_gpio_triggering(struct gpio_bank *bank, int gpio,
				    unsigned trigger)
{
	void __iomem *reg = bank->base;
	void __iomem *base = bank->base;
	u32 l = 0;

	if (bank->regs->leveldetect0 && bank->regs->wkup_en) {
		omap_set_gpio_trigger(bank, gpio, trigger);
	} else if (bank->regs->irqctrl) {
		reg += bank->regs->irqctrl;

		l = readl_relaxed(reg);
		if ((trigger & IRQ_TYPE_SENSE_MASK) == IRQ_TYPE_EDGE_BOTH)
			bank->toggle_mask |= BIT(gpio);
		if (trigger & IRQ_TYPE_EDGE_RISING)
			l |= BIT(gpio);
		else if (trigger & IRQ_TYPE_EDGE_FALLING)
			l &= ~(BIT(gpio));
		else
			return -EINVAL;

		writel_relaxed(l, reg);
	} else if (bank->regs->edgectrl1) {
		if (gpio & 0x08)
			reg += bank->regs->edgectrl2;
		else
			reg += bank->regs->edgectrl1;

		gpio &= 0x07;
		l = readl_relaxed(reg);
		l &= ~(3 << (gpio << 1));
		if (trigger & IRQ_TYPE_EDGE_RISING)
			l |= 2 << (gpio << 1);
		if (trigger & IRQ_TYPE_EDGE_FALLING)
			l |= BIT(gpio << 1);

		/* Enable wake-up during idle for dynamic tick */
		omap_gpio_rmw(base, bank->regs->wkup_en, BIT(gpio), trigger);
		bank->context.wake_en =
			readl_relaxed(bank->base + bank->regs->wkup_en);
		writel_relaxed(l, reg);
	}
	return 0;
}

static void omap_enable_gpio_module(struct gpio_bank *bank, unsigned offset)
{
	if (bank->regs->pinctrl) {
		void __iomem *reg = bank->base + bank->regs->pinctrl;

		/* Claim the pin for MPU */
		writel_relaxed(readl_relaxed(reg) | (BIT(offset)), reg);
	}

	if (bank->regs->ctrl && !BANK_USED(bank)) {
		void __iomem *reg = bank->base + bank->regs->ctrl;
		u32 ctrl;

		ctrl = readl_relaxed(reg);
		/* Module is enabled, clocks are not gated */
		ctrl &= ~GPIO_MOD_CTRL_BIT;
		writel_relaxed(ctrl, reg);
		bank->context.ctrl = ctrl;
	}
}

static void omap_disable_gpio_module(struct gpio_bank *bank, unsigned offset)
{
	void __iomem *base = bank->base;

	if (bank->regs->wkup_en &&
	    !LINE_USED(bank->mod_usage, offset) &&
	    !LINE_USED(bank->irq_usage, offset)) {
		/* Disable wake-up during idle for dynamic tick */
		omap_gpio_rmw(base, bank->regs->wkup_en, BIT(offset), 0);
		bank->context.wake_en =
			readl_relaxed(bank->base + bank->regs->wkup_en);
	}

	if (bank->regs->ctrl && !BANK_USED(bank)) {
		void __iomem *reg = bank->base + bank->regs->ctrl;
		u32 ctrl;

		ctrl = readl_relaxed(reg);
		/* Module is disabled, clocks are gated */
		ctrl |= GPIO_MOD_CTRL_BIT;
		writel_relaxed(ctrl, reg);
		bank->context.ctrl = ctrl;
	}
}

static int omap_gpio_is_input(struct gpio_bank *bank, unsigned offset)
{
	void __iomem *reg = bank->base + bank->regs->direction;

	return readl_relaxed(reg) & BIT(offset);
}

static void omap_gpio_init_irq(struct gpio_bank *bank, unsigned offset)
{
	if (!LINE_USED(bank->mod_usage, offset)) {
		omap_enable_gpio_module(bank, offset);
		omap_set_gpio_direction(bank, offset, 1);
	}
	bank->irq_usage |= BIT(offset);
}

static int omap_gpio_irq_type(struct irq_data *d, unsigned type)
{
	struct gpio_bank *bank = omap_irq_data_get_bank(d);
	int retval;
	unsigned long flags;
	unsigned offset = d->hwirq;

	if (type & ~IRQ_TYPE_SENSE_MASK)
		return -EINVAL;

	if (!bank->regs->leveldetect0 &&
		(type & (IRQ_TYPE_LEVEL_LOW|IRQ_TYPE_LEVEL_HIGH)))
		return -EINVAL;

	raw_spin_lock_irqsave(&bank->lock, flags);
	retval = omap_set_gpio_triggering(bank, offset, type);
	if (retval) {
		raw_spin_unlock_irqrestore(&bank->lock, flags);
		goto error;
	}
	omap_gpio_init_irq(bank, offset);
/*
	if (!omap_gpio_is_input(bank, offset)) {
		raw_spin_unlock_irqrestore(&bank->lock, flags);
		retval = -EINVAL;
		goto error;
	}
*/
	raw_spin_unlock_irqrestore(&bank->lock, flags);

	if (type & (IRQ_TYPE_LEVEL_LOW | IRQ_TYPE_LEVEL_HIGH))
		irq_set_handler_locked(d, handle_level_irq);
	else if (type & (IRQ_TYPE_EDGE_FALLING | IRQ_TYPE_EDGE_RISING))
		irq_set_handler_locked(d, handle_edge_irq);

	return 0;

error:
	return retval;
}

static void omap_clear_gpio_irqbank(struct gpio_bank *bank, int gpio_mask)
{
	void __iomem *reg = bank->base;

	reg += bank->regs->irqstatus;
	writel_relaxed(gpio_mask, reg);

	/* Workaround for clearing DSP GPIO interrupts to allow retention */
	if (bank->regs->irqstatus2) {
		reg = bank->base + bank->regs->irqstatus2;
		writel_relaxed(gpio_mask, reg);
	}

	/* Flush posted write for the irq status to avoid spurious interrupts */
	readl_relaxed(reg);
}

static inline void omap_clear_gpio_irqstatus(struct gpio_bank *bank,
					     unsigned offset)
{
	omap_clear_gpio_irqbank(bank, BIT(offset));
}

static u32 omap_get_gpio_irqbank_mask(struct gpio_bank *bank)
{
	void __iomem *reg = bank->base;
	u32 l;
	u32 mask = (BIT(bank->width)) - 1;

	reg += bank->regs->irqenable;
	l = readl_relaxed(reg);
	if (bank->regs->irqenable_inv)
		l = ~l;
	l &= mask;
	return l;
}

static void omap_enable_gpio_irqbank(struct gpio_bank *bank, int gpio_mask)
{
	void __iomem *reg = bank->base;
	u32 l;

	if (bank->regs->set_irqenable) {
		reg += bank->regs->set_irqenable;
		l = gpio_mask;
		bank->context.irqenable1 |= gpio_mask;
	} else {
		reg += bank->regs->irqenable;
		l = readl_relaxed(reg);
		if (bank->regs->irqenable_inv)
			l &= ~gpio_mask;
		else
			l |= gpio_mask;
		bank->context.irqenable1 = l;
	}

	writel_relaxed(l, reg);
}

static void omap_disable_gpio_irqbank(struct gpio_bank *bank, int gpio_mask)
{
	void __iomem *reg = bank->base;
	u32 l;

	if (bank->regs->clr_irqenable) {
		reg += bank->regs->clr_irqenable;
		l = gpio_mask;
		bank->context.irqenable1 &= ~gpio_mask;
	} else {
		reg += bank->regs->irqenable;
		l = readl_relaxed(reg);
		if (bank->regs->irqenable_inv)
			l |= gpio_mask;
		else
			l &= ~gpio_mask;
		bank->context.irqenable1 = l;
	}

	writel_relaxed(l, reg);
}

static inline void omap_set_gpio_irqenable(struct gpio_bank *bank,
					   unsigned offset, int enable)
{
	if (enable)
		omap_enable_gpio_irqbank(bank, BIT(offset));
	else
		omap_disable_gpio_irqbank(bank, BIT(offset));
}

/* Use disable_irq_wake() and enable_irq_wake() functions from drivers */
static int omap_gpio_wake_enable(struct irq_data *d, unsigned int enable)
{
	struct gpio_bank *bank = omap_irq_data_get_bank(d);

	return irq_set_irq_wake(bank->irq, enable);
}

static int omap_gpio_request(struct gpio_chip *chip, unsigned offset)
{
	struct gpio_bank *bank = container_of(chip, struct gpio_bank, chip);
	unsigned long flags;

	/*
	 * If this is the first gpio_request for the bank,
	 * enable the bank module.
	 */
	if (!BANK_USED(bank))
		pm_runtime_get_sync(bank->dev);

	raw_spin_lock_irqsave(&bank->lock, flags);
	omap_enable_gpio_module(bank, offset);
	bank->mod_usage |= BIT(offset);
	raw_spin_unlock_irqrestore(&bank->lock, flags);

	return 0;
}

static void omap_gpio_free(struct gpio_chip *chip, unsigned offset)
{
	struct gpio_bank *bank = container_of(chip, struct gpio_bank, chip);
	unsigned long flags;

	raw_spin_lock_irqsave(&bank->lock, flags);
	bank->mod_usage &= ~(BIT(offset));
	if (!LINE_USED(bank->irq_usage, offset)) {
		omap_set_gpio_direction(bank, offset, 1);
		omap_clear_gpio_debounce(bank, offset);
	}
	omap_disable_gpio_module(bank, offset);
	raw_spin_unlock_irqrestore(&bank->lock, flags);

	/*
	 * If this is the last gpio to be freed in the bank,
	 * disable the bank module.
	 */
	if (!BANK_USED(bank))
		pm_runtime_put(bank->dev);
}

/*
 * We need to unmask the GPIO bank interrupt as soon as possible to
 * avoid missing GPIO interrupts for other lines in the bank.
 * Then we need to mask-read-clear-unmask the triggered GPIO lines
 * in the bank to avoid missing nested interrupts for a GPIO line.
 * If we wait to unmask individual GPIO lines in the bank after the
 * line's interrupt handler has been run, we may miss some nested
 * interrupts.
 */
static irqreturn_t omap_gpio_irq_handler(int irq, void *gpiobank)
{
	void __iomem *isr_reg = NULL;
	u32 isr;
	unsigned int bit;
	struct gpio_bank *bank = gpiobank;
	unsigned long wa_lock_flags;
	unsigned long lock_flags;

	isr_reg = bank->base + bank->regs->irqstatus;
	if (WARN_ON(!isr_reg))
		goto exit;

	pm_runtime_get_sync(bank->dev);

	while (1) {
		u32 isr_saved, level_mask = 0;
		u32 enabled;

		raw_spin_lock_irqsave(&bank->lock, lock_flags);

		enabled = omap_get_gpio_irqbank_mask(bank);
		isr_saved = isr = readl_relaxed(isr_reg) & enabled;

		if (bank->level_mask)
			level_mask = bank->level_mask & enabled;

		/* clear edge sensitive interrupts before handler(s) are
		called so that we don't miss any interrupt occurred while
		executing them */
		omap_disable_gpio_irqbank(bank, isr_saved & ~level_mask);
		omap_clear_gpio_irqbank(bank, isr_saved & ~level_mask);
		omap_enable_gpio_irqbank(bank, isr_saved & ~level_mask);

		raw_spin_unlock_irqrestore(&bank->lock, lock_flags);

		if (!isr)
			break;

		while (isr) {
			bit = __ffs(isr);
			isr &= ~(BIT(bit));

			raw_spin_lock_irqsave(&bank->lock, lock_flags);
			/*
			 * Some chips can't respond to both rising and falling
			 * at the same time.  If this irq was requested with
			 * both flags, we need to flip the ICR data for the IRQ
			 * to respond to the IRQ for the opposite direction.
			 * This will be indicated in the bank toggle_mask.
			 */
			if (bank->toggle_mask & (BIT(bit)))
				omap_toggle_gpio_edge_triggering(bank, bit);

			raw_spin_unlock_irqrestore(&bank->lock, lock_flags);

			raw_spin_lock_irqsave(&bank->wa_lock, wa_lock_flags);

			generic_handle_irq(irq_find_mapping(bank->chip.irqdomain,
							    bit));

			raw_spin_unlock_irqrestore(&bank->wa_lock,
						   wa_lock_flags);
		}
	}
exit:
	pm_runtime_put(bank->dev);
	return IRQ_HANDLED;
}

static unsigned int omap_gpio_irq_startup(struct irq_data *d)
{
	struct gpio_bank *bank = omap_irq_data_get_bank(d);
	unsigned long flags;
	unsigned offset = d->hwirq;

	raw_spin_lock_irqsave(&bank->lock, flags);

	if (!LINE_USED(bank->mod_usage, offset))
		omap_set_gpio_direction(bank, offset, 1);
/*
	else if (!omap_gpio_is_input(bank, offset))
		goto err;
*/
	omap_enable_gpio_module(bank, offset);
	bank->irq_usage |= BIT(offset);

	raw_spin_unlock_irqrestore(&bank->lock, flags);
	omap_gpio_unmask_irq(d);

	return 0;
err:
	raw_spin_unlock_irqrestore(&bank->lock, flags);
	return -EINVAL;
}

static void omap_gpio_irq_shutdown(struct irq_data *d)
{
	struct gpio_bank *bank = omap_irq_data_get_bank(d);
	unsigned long flags;
	unsigned offset = d->hwirq;

	raw_spin_lock_irqsave(&bank->lock, flags);
	bank->irq_usage &= ~(BIT(offset));
	omap_set_gpio_irqenable(bank, offset, 0);
	omap_clear_gpio_irqstatus(bank, offset);
	omap_set_gpio_triggering(bank, offset, IRQ_TYPE_NONE);
	if (!LINE_USED(bank->mod_usage, offset))
		omap_clear_gpio_debounce(bank, offset);
	omap_disable_gpio_module(bank, offset);
	raw_spin_unlock_irqrestore(&bank->lock, flags);
}

static void omap_gpio_irq_bus_lock(struct irq_data *data)
{
	struct gpio_bank *bank = omap_irq_data_get_bank(data);

	if (!BANK_USED(bank))
		pm_runtime_get_sync(bank->dev);
}

static void gpio_irq_bus_sync_unlock(struct irq_data *data)
{
	struct gpio_bank *bank = omap_irq_data_get_bank(data);

	/*
	 * If this is the last IRQ to be freed in the bank,
	 * disable the bank module.
	 */
	if (!BANK_USED(bank))
		pm_runtime_put(bank->dev);
}

static void omap_gpio_ack_irq(struct irq_data *d)
{
	struct gpio_bank *bank = omap_irq_data_get_bank(d);
	unsigned offset = d->hwirq;

	omap_clear_gpio_irqstatus(bank, offset);
}

static void omap_gpio_mask_irq(struct irq_data *d)
{
	struct gpio_bank *bank = omap_irq_data_get_bank(d);
	unsigned offset = d->hwirq;
	unsigned long flags;

	raw_spin_lock_irqsave(&bank->lock, flags);
	omap_set_gpio_irqenable(bank, offset, 0);
	omap_set_gpio_triggering(bank, offset, IRQ_TYPE_NONE);
	raw_spin_unlock_irqrestore(&bank->lock, flags);
}

static void omap_gpio_unmask_irq(struct irq_data *d)
{
	struct gpio_bank *bank = omap_irq_data_get_bank(d);
	unsigned offset = d->hwirq;
	u32 trigger = irqd_get_trigger_type(d);
	unsigned long flags;

	raw_spin_lock_irqsave(&bank->lock, flags);
	if (trigger)
		omap_set_gpio_triggering(bank, offset, trigger);

	/* For level-triggered GPIOs, the clearing must be done after
	 * the HW source is cleared, thus after the handler has run */
	if (bank->level_mask & BIT(offset)) {
		omap_set_gpio_irqenable(bank, offset, 0);
		omap_clear_gpio_irqstatus(bank, offset);
	}

	omap_set_gpio_irqenable(bank, offset, 1);
	raw_spin_unlock_irqrestore(&bank->lock, flags);
}

/*---------------------------------------------------------------------*/

static int omap_mpuio_suspend_noirq(struct device *dev)
{
	struct platform_device *pdev = to_platform_device(dev);
	struct gpio_bank	*bank = platform_get_drvdata(pdev);
	void __iomem		*mask_reg = bank->base +
					OMAP_MPUIO_GPIO_MASKIT / bank->stride;
	unsigned long		flags;

	raw_spin_lock_irqsave(&bank->lock, flags);
	writel_relaxed(0xffff & ~bank->context.wake_en, mask_reg);
	raw_spin_unlock_irqrestore(&bank->lock, flags);

	return 0;
}

static int omap_mpuio_resume_noirq(struct device *dev)
{
	struct platform_device *pdev = to_platform_device(dev);
	struct gpio_bank	*bank = platform_get_drvdata(pdev);
	void __iomem		*mask_reg = bank->base +
					OMAP_MPUIO_GPIO_MASKIT / bank->stride;
	unsigned long		flags;

	raw_spin_lock_irqsave(&bank->lock, flags);
	writel_relaxed(bank->context.wake_en, mask_reg);
	raw_spin_unlock_irqrestore(&bank->lock, flags);

	return 0;
}

static const struct dev_pm_ops omap_mpuio_dev_pm_ops = {
	.suspend_noirq = omap_mpuio_suspend_noirq,
	.resume_noirq = omap_mpuio_resume_noirq,
};

/* use platform_driver for this. */
static struct platform_driver omap_mpuio_driver = {
	.driver		= {
		.name	= "mpuio",
		.pm	= &omap_mpuio_dev_pm_ops,
	},
};

static struct platform_device omap_mpuio_device = {
	.name		= "mpuio",
	.id		= -1,
	.dev = {
		.driver = &omap_mpuio_driver.driver,
	}
	/* could list the /proc/iomem resources */
};

static inline void omap_mpuio_init(struct gpio_bank *bank)
{
	platform_set_drvdata(&omap_mpuio_device, bank);

	if (platform_driver_register(&omap_mpuio_driver) == 0)
		(void) platform_device_register(&omap_mpuio_device);
}

/*---------------------------------------------------------------------*/

static int omap_gpio_get_direction(struct gpio_chip *chip, unsigned offset)
{
	struct gpio_bank *bank;
	unsigned long flags;
	void __iomem *reg;
	int dir;

	bank = container_of(chip, struct gpio_bank, chip);
	reg = bank->base + bank->regs->direction;
	raw_spin_lock_irqsave(&bank->lock, flags);
	dir = !!(readl_relaxed(reg) & BIT(offset));
	raw_spin_unlock_irqrestore(&bank->lock, flags);
	return dir;
}

static int omap_gpio_input(struct gpio_chip *chip, unsigned offset)
{
	struct gpio_bank *bank;
	unsigned long flags;

	bank = container_of(chip, struct gpio_bank, chip);
	raw_spin_lock_irqsave(&bank->lock, flags);
	omap_set_gpio_direction(bank, offset, 1);
	raw_spin_unlock_irqrestore(&bank->lock, flags);
	return 0;
}

static int omap_gpio_get(struct gpio_chip *chip, unsigned offset)
{
	struct gpio_bank *bank;

	bank = container_of(chip, struct gpio_bank, chip);

	if (omap_gpio_is_input(bank, offset))
		return omap_get_gpio_datain(bank, offset);
	else
		return omap_get_gpio_dataout(bank, offset);
}

static int omap_gpio_output(struct gpio_chip *chip, unsigned offset, int value)
{
	struct gpio_bank *bank;
	unsigned long flags;

	bank = container_of(chip, struct gpio_bank, chip);
	raw_spin_lock_irqsave(&bank->lock, flags);
	bank->set_dataout(bank, offset, value);
	omap_set_gpio_direction(bank, offset, 0);
	raw_spin_unlock_irqrestore(&bank->lock, flags);
	return 0;
}

static int omap_gpio_debounce(struct gpio_chip *chip, unsigned offset,
			      unsigned debounce)
{
	struct gpio_bank *bank;
	unsigned long flags;

	bank = container_of(chip, struct gpio_bank, chip);

	raw_spin_lock_irqsave(&bank->lock, flags);
	omap2_set_gpio_debounce(bank, offset, debounce);
	raw_spin_unlock_irqrestore(&bank->lock, flags);

	return 0;
}

static void omap_gpio_set(struct gpio_chip *chip, unsigned offset, int value)
{
	struct gpio_bank *bank;
	unsigned long flags;

	bank = container_of(chip, struct gpio_bank, chip);
	raw_spin_lock_irqsave(&bank->lock, flags);
	bank->set_dataout(bank, offset, value);
	raw_spin_unlock_irqrestore(&bank->lock, flags);
}

/*---------------------------------------------------------------------*/

static void __init omap_gpio_show_rev(struct gpio_bank *bank)
{
	static bool called;
	u32 rev;

	if (called || bank->regs->revision == USHRT_MAX)
		return;

	rev = readw_relaxed(bank->base + bank->regs->revision);
	pr_info("OMAP GPIO hardware version %d.%d\n",
		(rev >> 4) & 0x0f, rev & 0x0f);

	called = true;
}

static void omap_gpio_mod_init(struct gpio_bank *bank)
{
	void __iomem *base = bank->base;
	u32 l = 0xffffffff;

	if (bank->width == 16)
		l = 0xffff;

	if (bank->is_mpuio) {
		writel_relaxed(l, bank->base + bank->regs->irqenable);
		return;
	}

	omap_gpio_rmw(base, bank->regs->irqenable, l,
		      bank->regs->irqenable_inv);
	omap_gpio_rmw(base, bank->regs->irqstatus, l,
		      !bank->regs->irqenable_inv);
	if (bank->regs->debounce_en)
		writel_relaxed(0, base + bank->regs->debounce_en);

	/* Save OE default value (0xffffffff) in the context */
	bank->context.oe = readl_relaxed(bank->base + bank->regs->direction);
	 /* Initialize interface clk ungated, module enabled */
	if (bank->regs->ctrl)
		writel_relaxed(0, base + bank->regs->ctrl);
}

static int omap_gpio_chip_init(struct gpio_bank *bank, struct irq_chip *irqc)
{
	static int gpio;
	int irq_base = 0;
	int ret;

	/*
	 * REVISIT eventually switch from OMAP-specific gpio structs
	 * over to the generic ones
	 */
	bank->chip.request = omap_gpio_request;
	bank->chip.free = omap_gpio_free;
	bank->chip.get_direction = omap_gpio_get_direction;
	bank->chip.direction_input = omap_gpio_input;
	bank->chip.get = omap_gpio_get;
	bank->chip.direction_output = omap_gpio_output;
	bank->chip.set_debounce = omap_gpio_debounce;
	bank->chip.set = omap_gpio_set;
	if (bank->is_mpuio) {
		bank->chip.label = "mpuio";
		if (bank->regs->wkup_en)
			bank->chip.dev = &omap_mpuio_device.dev;
		bank->chip.base = OMAP_MPUIO(0);
	} else {
		bank->chip.label = "gpio";
		bank->chip.base = gpio;
	}
	bank->chip.ngpio = bank->width;

	ret = gpiochip_add(&bank->chip);
	if (ret) {
		dev_err(bank->dev, "Could not register gpio chip %d\n", ret);
		return ret;
	}

	if (!bank->is_mpuio)
		gpio += bank->width;

#ifdef CONFIG_ARCH_OMAP1
	/*
	 * REVISIT: Once we have OMAP1 supporting SPARSE_IRQ, we can drop
	 * irq_alloc_descs() since a base IRQ offset will no longer be needed.
	 */
	irq_base = irq_alloc_descs(-1, 0, bank->width, 0);
	if (irq_base < 0) {
		dev_err(bank->dev, "Couldn't allocate IRQ numbers\n");
		return -ENODEV;
	}
#endif

	/* MPUIO is a bit different, reading IRQ status clears it */
	if (bank->is_mpuio) {
		irqc->irq_ack = dummy_irq_chip.irq_ack;
		if (!bank->regs->wkup_en)
			irqc->irq_set_wake = NULL;
	}

	ret = gpiochip_irqchip_add(&bank->chip, irqc,
				   irq_base, handle_bad_irq,
				   IRQ_TYPE_NONE);

	if (ret) {
		dev_err(bank->dev, "Couldn't add irqchip to gpiochip %d\n", ret);
		gpiochip_remove(&bank->chip);
		return -ENODEV;
	}

	gpiochip_set_chained_irqchip(&bank->chip, irqc, bank->irq, NULL);

	ret = devm_request_irq(bank->dev, bank->irq, omap_gpio_irq_handler,
			       0, dev_name(bank->dev), bank);
	if (ret)
		gpiochip_remove(&bank->chip);

	return ret;
}

static const struct of_device_id omap_gpio_match[];

static int omap_gpio_probe(struct platform_device *pdev)
{
	struct device *dev = &pdev->dev;
	struct device_node *node = dev->of_node;
	const struct of_device_id *match;
	const struct omap_gpio_platform_data *pdata;
	struct resource *res;
	struct gpio_bank *bank;
	struct irq_chip *irqc;
	int ret;

	match = of_match_device(of_match_ptr(omap_gpio_match), dev);

	pdata = match ? match->data : dev_get_platdata(dev);
	if (!pdata)
		return -EINVAL;

	bank = devm_kzalloc(dev, sizeof(struct gpio_bank), GFP_KERNEL);
	if (!bank) {
		dev_err(dev, "Memory alloc failed\n");
		return -ENOMEM;
	}

	irqc = devm_kzalloc(dev, sizeof(*irqc), GFP_KERNEL);
	if (!irqc)
		return -ENOMEM;

	irqc->irq_startup = omap_gpio_irq_startup,
	irqc->irq_shutdown = omap_gpio_irq_shutdown,
	irqc->irq_ack = omap_gpio_ack_irq,
	irqc->irq_mask = omap_gpio_mask_irq,
	irqc->irq_unmask = omap_gpio_unmask_irq,
	irqc->irq_set_type = omap_gpio_irq_type,
	irqc->irq_set_wake = omap_gpio_wake_enable,
	irqc->irq_bus_lock = omap_gpio_irq_bus_lock,
	irqc->irq_bus_sync_unlock = gpio_irq_bus_sync_unlock,
	irqc->name = dev_name(&pdev->dev);
	irqc->flags = IRQCHIP_MASK_ON_SUSPEND;

	bank->irq = platform_get_irq(pdev, 0);
	if (bank->irq <= 0) {
		if (!bank->irq)
			bank->irq = -ENXIO;
		if (bank->irq != -EPROBE_DEFER)
			dev_err(dev,
				"can't get irq resource ret=%d\n", bank->irq);
		return bank->irq;
	}

	bank->dev = dev;
	bank->chip.dev = dev;
	bank->chip.owner = THIS_MODULE;
	bank->dbck_flag = pdata->dbck_flag;
	bank->stride = pdata->bank_stride;
	bank->width = pdata->bank_width;
	bank->is_mpuio = pdata->is_mpuio;
	bank->non_wakeup_gpios = pdata->non_wakeup_gpios;
	bank->regs = pdata->regs;
#ifdef CONFIG_OF_GPIO
	bank->chip.of_node = of_node_get(node);
#endif
	if (!node) {
		bank->get_context_loss_count =
			pdata->get_context_loss_count;
	}

	if (bank->regs->set_dataout && bank->regs->clr_dataout)
		bank->set_dataout = omap_set_gpio_dataout_reg;
	else
		bank->set_dataout = omap_set_gpio_dataout_mask;

	raw_spin_lock_init(&bank->lock);
	raw_spin_lock_init(&bank->wa_lock);

	/* Static mapping, never released */
	res = platform_get_resource(pdev, IORESOURCE_MEM, 0);
	bank->base = devm_ioremap_resource(dev, res);
	if (IS_ERR(bank->base)) {
		return PTR_ERR(bank->base);
	}

	if (bank->dbck_flag) {
		bank->dbck = devm_clk_get(bank->dev, "dbclk");
		if (IS_ERR(bank->dbck)) {
			dev_err(bank->dev,
				"Could not get gpio dbck. Disable debounce\n");
			bank->dbck_flag = false;
		} else {
			clk_prepare(bank->dbck);
		}
	}

	platform_set_drvdata(pdev, bank);

	pm_runtime_enable(bank->dev);
	pm_runtime_irq_safe(bank->dev);
	pm_runtime_get_sync(bank->dev);

	if (bank->is_mpuio)
		omap_mpuio_init(bank);

	omap_gpio_mod_init(bank);

	ret = omap_gpio_chip_init(bank, irqc);
	if (ret) {
		pm_runtime_put_sync(bank->dev);
		pm_runtime_disable(bank->dev);
		return ret;
	}

	omap_gpio_show_rev(bank);

	pm_runtime_put(bank->dev);

	list_add_tail(&bank->node, &omap_gpio_list);

	return 0;
}

static int omap_gpio_remove(struct platform_device *pdev)
{
	struct gpio_bank *bank = platform_get_drvdata(pdev);

	list_del(&bank->node);
	gpiochip_remove(&bank->chip);
	pm_runtime_disable(bank->dev);
	if (bank->dbck_flag)
		clk_unprepare(bank->dbck);

	return 0;
}

#ifdef CONFIG_ARCH_OMAP2PLUS

#if defined(CONFIG_PM)
static void omap_gpio_restore_context(struct gpio_bank *bank);

static int omap_gpio_runtime_suspend(struct device *dev)
{
	struct platform_device *pdev = to_platform_device(dev);
	struct gpio_bank *bank = platform_get_drvdata(pdev);
	u32 l1 = 0, l2 = 0;
	unsigned long flags;
	u32 wake_low, wake_hi;

	raw_spin_lock_irqsave(&bank->lock, flags);

	/*
	 * Only edges can generate a wakeup event to the PRCM.
	 *
	 * Therefore, ensure any wake-up capable GPIOs have
	 * edge-detection enabled before going idle to ensure a wakeup
	 * to the PRCM is generated on a GPIO transition. (c.f. 34xx
	 * NDA TRM 25.5.3.1)
	 *
	 * The normal values will be restored upon ->runtime_resume()
	 * by writing back the values saved in bank->context.
	 */
	wake_low = bank->context.leveldetect0 & bank->context.wake_en;
	if (wake_low)
		writel_relaxed(wake_low | bank->context.fallingdetect,
			     bank->base + bank->regs->fallingdetect);
	wake_hi = bank->context.leveldetect1 & bank->context.wake_en;
	if (wake_hi)
		writel_relaxed(wake_hi | bank->context.risingdetect,
			     bank->base + bank->regs->risingdetect);

	if (!bank->enabled_non_wakeup_gpios)
		goto update_gpio_context_count;

	if (bank->power_mode != OFF_MODE) {
		bank->power_mode = 0;
		goto update_gpio_context_count;
	}
	/*
	 * If going to OFF, remove triggering for all
	 * non-wakeup GPIOs.  Otherwise spurious IRQs will be
	 * generated.  See OMAP2420 Errata item 1.101.
	 */
	bank->saved_datain = readl_relaxed(bank->base +
						bank->regs->datain);
	l1 = bank->context.fallingdetect;
	l2 = bank->context.risingdetect;

	l1 &= ~bank->enabled_non_wakeup_gpios;
	l2 &= ~bank->enabled_non_wakeup_gpios;

	writel_relaxed(l1, bank->base + bank->regs->fallingdetect);
	writel_relaxed(l2, bank->base + bank->regs->risingdetect);

	bank->workaround_enabled = true;

update_gpio_context_count:
	if (bank->get_context_loss_count)
		bank->context_loss_count =
				bank->get_context_loss_count(bank->dev);

	omap_gpio_dbck_disable(bank);
	raw_spin_unlock_irqrestore(&bank->lock, flags);

	return 0;
}

static void omap_gpio_init_context(struct gpio_bank *p);

static int omap_gpio_runtime_resume(struct device *dev)
{
	struct platform_device *pdev = to_platform_device(dev);
	struct gpio_bank *bank = platform_get_drvdata(pdev);
	u32 l = 0, gen, gen0, gen1;
	unsigned long flags;
	int c;

	raw_spin_lock_irqsave(&bank->lock, flags);

	/*
	 * On the first resume during the probe, the context has not
	 * been initialised and so initialise it now. Also initialise
	 * the context loss count.
	 */
	if (!bank->context_valid) {
		omap_gpio_init_context(bank);

		if (bank->get_context_loss_count)
			bank->context_loss_count =
				bank->get_context_loss_count(bank->dev);
	}

	omap_gpio_dbck_enable(bank);

	/*
	 * In ->runtime_suspend(), level-triggered, wakeup-enabled
	 * GPIOs were set to edge trigger also in order to be able to
	 * generate a PRCM wakeup.  Here we restore the
	 * pre-runtime_suspend() values for edge triggering.
	 */
	writel_relaxed(bank->context.fallingdetect,
		     bank->base + bank->regs->fallingdetect);
	writel_relaxed(bank->context.risingdetect,
		     bank->base + bank->regs->risingdetect);

	if (!bank->get_context_loss_count) {
		omap_gpio_restore_context(bank);
	} else {
		c = bank->get_context_loss_count(bank->dev);
		if (c != bank->context_loss_count) {
			raw_spin_unlock_irqrestore(&bank->lock, flags);
			return 0;
		}
	}

	if (!bank->workaround_enabled) {
		raw_spin_unlock_irqrestore(&bank->lock, flags);
		return 0;
	}

	l = readl_relaxed(bank->base + bank->regs->datain);

	/*
	 * Check if any of the non-wakeup interrupt GPIOs have changed
	 * state.  If so, generate an IRQ by software.  This is
	 * horribly racy, but it's the best we can do to work around
	 * this silicon bug.
	 */
	l ^= bank->saved_datain;
	l &= bank->enabled_non_wakeup_gpios;

	/*
	 * No need to generate IRQs for the rising edge for gpio IRQs
	 * configured with falling edge only; and vice versa.
	 */
	gen0 = l & bank->context.fallingdetect;
	gen0 &= bank->saved_datain;

	gen1 = l & bank->context.risingdetect;
	gen1 &= ~(bank->saved_datain);

	/* FIXME: Consider GPIO IRQs with level detections properly! */
	gen = l & (~(bank->context.fallingdetect) &
					 ~(bank->context.risingdetect));
	/* Consider all GPIO IRQs needed to be updated */
	gen |= gen0 | gen1;

	if (gen) {
		u32 old0, old1;

		old0 = readl_relaxed(bank->base + bank->regs->leveldetect0);
		old1 = readl_relaxed(bank->base + bank->regs->leveldetect1);

		if (!bank->regs->irqstatus_raw0) {
			writel_relaxed(old0 | gen, bank->base +
						bank->regs->leveldetect0);
			writel_relaxed(old1 | gen, bank->base +
						bank->regs->leveldetect1);
		}

		if (bank->regs->irqstatus_raw0) {
			writel_relaxed(old0 | l, bank->base +
						bank->regs->leveldetect0);
			writel_relaxed(old1 | l, bank->base +
						bank->regs->leveldetect1);
		}
		writel_relaxed(old0, bank->base + bank->regs->leveldetect0);
		writel_relaxed(old1, bank->base + bank->regs->leveldetect1);
	}

	bank->workaround_enabled = false;
	raw_spin_unlock_irqrestore(&bank->lock, flags);

	return 0;
}
#endif /* CONFIG_PM */

#if IS_BUILTIN(CONFIG_GPIO_OMAP)
void omap2_gpio_prepare_for_idle(int pwr_mode)
{
	struct gpio_bank *bank;

	list_for_each_entry(bank, &omap_gpio_list, node) {
		if (!BANK_USED(bank))
			continue;

		bank->power_mode = pwr_mode;

		pm_runtime_put_sync_suspend(bank->dev);
	}
}

void omap2_gpio_resume_after_idle(void)
{
	struct gpio_bank *bank;

	list_for_each_entry(bank, &omap_gpio_list, node) {
		if (!BANK_USED(bank))
			continue;

		pm_runtime_get_sync(bank->dev);
	}
}
#endif

#if defined(CONFIG_PM)
static void omap_gpio_init_context(struct gpio_bank *p)
{
	struct omap_gpio_reg_offs *regs = p->regs;
	void __iomem *base = p->base;

	p->context.ctrl		= readl_relaxed(base + regs->ctrl);
	p->context.oe		= readl_relaxed(base + regs->direction);
	p->context.wake_en	= readl_relaxed(base + regs->wkup_en);
	p->context.leveldetect0	= readl_relaxed(base + regs->leveldetect0);
	p->context.leveldetect1	= readl_relaxed(base + regs->leveldetect1);
	p->context.risingdetect	= readl_relaxed(base + regs->risingdetect);
	p->context.fallingdetect = readl_relaxed(base + regs->fallingdetect);
	p->context.irqenable1	= readl_relaxed(base + regs->irqenable);
	p->context.irqenable2	= readl_relaxed(base + regs->irqenable2);

	if (regs->set_dataout && p->regs->clr_dataout)
		p->context.dataout = readl_relaxed(base + regs->set_dataout);
	else
		p->context.dataout = readl_relaxed(base + regs->dataout);

	p->context_valid = true;
}

static void omap_gpio_restore_context(struct gpio_bank *bank)
{
	writel_relaxed(bank->context.wake_en,
				bank->base + bank->regs->wkup_en);
	writel_relaxed(bank->context.ctrl, bank->base + bank->regs->ctrl);
	writel_relaxed(bank->context.leveldetect0,
				bank->base + bank->regs->leveldetect0);
	writel_relaxed(bank->context.leveldetect1,
				bank->base + bank->regs->leveldetect1);
	writel_relaxed(bank->context.risingdetect,
				bank->base + bank->regs->risingdetect);
	writel_relaxed(bank->context.fallingdetect,
				bank->base + bank->regs->fallingdetect);
	if (bank->regs->set_dataout && bank->regs->clr_dataout)
		writel_relaxed(bank->context.dataout,
				bank->base + bank->regs->set_dataout);
	else
		writel_relaxed(bank->context.dataout,
				bank->base + bank->regs->dataout);
	writel_relaxed(bank->context.oe, bank->base + bank->regs->direction);

	if (bank->dbck_enable_mask) {
		writel_relaxed(bank->context.debounce, bank->base +
					bank->regs->debounce);
		writel_relaxed(bank->context.debounce_en,
					bank->base + bank->regs->debounce_en);
	}

	writel_relaxed(bank->context.irqenable1,
				bank->base + bank->regs->irqenable);
	writel_relaxed(bank->context.irqenable2,
				bank->base + bank->regs->irqenable2);
}
#endif /* CONFIG_PM */
#else
#define omap_gpio_runtime_suspend NULL
#define omap_gpio_runtime_resume NULL
static inline void omap_gpio_init_context(struct gpio_bank *p) {}
#endif

static const struct dev_pm_ops gpio_pm_ops = {
	SET_RUNTIME_PM_OPS(omap_gpio_runtime_suspend, omap_gpio_runtime_resume,
									NULL)
};

#if defined(CONFIG_OF)
static struct omap_gpio_reg_offs omap2_gpio_regs = {
	.revision =		OMAP24XX_GPIO_REVISION,
	.direction =		OMAP24XX_GPIO_OE,
	.datain =		OMAP24XX_GPIO_DATAIN,
	.dataout =		OMAP24XX_GPIO_DATAOUT,
	.set_dataout =		OMAP24XX_GPIO_SETDATAOUT,
	.clr_dataout =		OMAP24XX_GPIO_CLEARDATAOUT,
	.irqstatus =		OMAP24XX_GPIO_IRQSTATUS1,
	.irqstatus2 =		OMAP24XX_GPIO_IRQSTATUS2,
	.irqenable =		OMAP24XX_GPIO_IRQENABLE1,
	.irqenable2 =		OMAP24XX_GPIO_IRQENABLE2,
	.set_irqenable =	OMAP24XX_GPIO_SETIRQENABLE1,
	.clr_irqenable =	OMAP24XX_GPIO_CLEARIRQENABLE1,
	.debounce =		OMAP24XX_GPIO_DEBOUNCE_VAL,
	.debounce_en =		OMAP24XX_GPIO_DEBOUNCE_EN,
	.ctrl =			OMAP24XX_GPIO_CTRL,
	.wkup_en =		OMAP24XX_GPIO_WAKE_EN,
	.leveldetect0 =		OMAP24XX_GPIO_LEVELDETECT0,
	.leveldetect1 =		OMAP24XX_GPIO_LEVELDETECT1,
	.risingdetect =		OMAP24XX_GPIO_RISINGDETECT,
	.fallingdetect =	OMAP24XX_GPIO_FALLINGDETECT,
};

static struct omap_gpio_reg_offs omap4_gpio_regs = {
	.revision =		OMAP4_GPIO_REVISION,
	.direction =		OMAP4_GPIO_OE,
	.datain =		OMAP4_GPIO_DATAIN,
	.dataout =		OMAP4_GPIO_DATAOUT,
	.set_dataout =		OMAP4_GPIO_SETDATAOUT,
	.clr_dataout =		OMAP4_GPIO_CLEARDATAOUT,
	.irqstatus =		OMAP4_GPIO_IRQSTATUS0,
	.irqstatus2 =		OMAP4_GPIO_IRQSTATUS1,
	.irqenable =		OMAP4_GPIO_IRQSTATUSSET0,
	.irqenable2 =		OMAP4_GPIO_IRQSTATUSSET1,
	.set_irqenable =	OMAP4_GPIO_IRQSTATUSSET0,
	.clr_irqenable =	OMAP4_GPIO_IRQSTATUSCLR0,
	.debounce =		OMAP4_GPIO_DEBOUNCINGTIME,
	.debounce_en =		OMAP4_GPIO_DEBOUNCENABLE,
	.ctrl =			OMAP4_GPIO_CTRL,
	.wkup_en =		OMAP4_GPIO_IRQWAKEN0,
	.leveldetect0 =		OMAP4_GPIO_LEVELDETECT0,
	.leveldetect1 =		OMAP4_GPIO_LEVELDETECT1,
	.risingdetect =		OMAP4_GPIO_RISINGDETECT,
	.fallingdetect =	OMAP4_GPIO_FALLINGDETECT,
};

static const struct omap_gpio_platform_data omap2_pdata = {
	.regs = &omap2_gpio_regs,
	.bank_width = 32,
	.dbck_flag = false,
};

static const struct omap_gpio_platform_data omap3_pdata = {
	.regs = &omap2_gpio_regs,
	.bank_width = 32,
	.dbck_flag = true,
};

static const struct omap_gpio_platform_data omap4_pdata = {
	.regs = &omap4_gpio_regs,
	.bank_width = 32,
	.dbck_flag = true,
};

static const struct of_device_id omap_gpio_match[] = {
	{
		.compatible = "ELEC553_RL59",
		.data = &omap4_pdata,
	},
	{
		.compatible = "ti,omap3-gpio",
		.data = &omap3_pdata,
	},
	{
		.compatible = "ti,omap2-gpio",
		.data = &omap2_pdata,
	},
	{ },
};
MODULE_DEVICE_TABLE(of, omap_gpio_match);
#endif

static struct platform_driver omap_gpio_driver = {
	.probe		= omap_gpio_probe,
	.remove		= omap_gpio_remove,
	.driver		= {
		.name	= "omap_gpio",
		.pm	= &gpio_pm_ops,
		.of_match_table = of_match_ptr(omap_gpio_match),
	},
};

//lab2 part
#define max_memory 1048576
#define max_regions_number 10 //to test easily, use 10
#define DEVICE_NAME "mymem_smart"// Dev name as it appears in /proc/devices
#define MEMDEV_MAJOR 254
 

//define the magic number
#define MEMDEV_IOC_MAGIC  'k'

//define the <ioctl> cmd
#define MEMDEV_IOCPRINT   _IO(MEMDEV_IOC_MAGIC, 1)
#define MEMDEV_IOCGETDATA _IOR(MEMDEV_IOC_MAGIC, 2, int)
#define MEMDEV_IOCSETDATA _IOW(MEMDEV_IOC_MAGIC, 3, int)

#define MYMEM_IOCTL_ALLOC _IOW(MEMDEV_IOC_MAGIC, 4, int)
#define MYMEM_IOCTL_FREE  _IOW(MEMDEV_IOC_MAGIC, 5, int)
#define MYMEM_IOCTL_SETREGION _IOW(MEMDEV_IOC_MAGIC, 6, int)
#define DELAY_SECONDS  _IOW(MEMDEV_IOC_MAGIC, 7, int)
#define TOUCH_SENSOR   _IOW(MEMDEV_IOC_MAGIC, 8, int)

#define MEMDEV_IOC_MAXNR 8


int init_module(void);
void cleanup_module(void);
static int device_open(struct inode *, struct file *);
static int device_release(struct inode *, struct file *);
static ssize_t device_read(struct file *, char *, size_t, loff_t *);
static ssize_t device_write(struct file *, const char *, size_t, loff_t *);
static loff_t device_llseek(struct file *, loff_t, int);
static long device_ioctl(struct file *, unsigned int, unsigned long);

static int test_ioarg = 0;
static dev_t first;         // Global variable for the first device number
static struct cdev c_dev;     // Global variable for the character device structure
static struct class *cl;     // Global variable for the device class

static int ID_active=0;
module_param(ID_active, int, S_IRUGO);

static long allocated=0;
module_param(allocated, long, S_IRUGO);

static int len2=max_regions_number*2;

static long regions[max_regions_number*2]={0};     //regions[even]= each region's ID, regions[odd]=each region's size
module_param_array(regions, long, &len2, S_IRUGO);

static int len1=60;
static char* history[60];
module_param_array(history, charp, &len1, S_IRUGO);
static int num_h=0;

static int region_count=0;  //current numbers of the regions
module_param(region_count, int, S_IRUGO);



int t_end = -100;
static unsigned int irqNumber;
int t_start;
static long current_region_size; //default value of the allocated region size



struct mem_dev                                     
{                                                        
  int ID;        //ID >= 1, for example Region1,Region2,...
  char *data;                      
  long size; //size of the region      
};

struct mem_dev* mem_region;
 
static struct file_operations fops = {
        .owner=THIS_MODULE,
	.read = device_read,
        .llseek=device_llseek,
	.write = device_write,
	.open = device_open,
        .unlocked_ioctl=device_ioctl,
	.release = device_release
};

int time_h_to_l_1, time_h_to_l_2, time_h_to_l;
module_param(time_h_to_l,int,S_IRUGO|S_IWUSR); 

int touched_or_not;//1 for touched 0 for not touhced
module_param(touched_or_not,int,S_IRUGO|S_IWUSR); 

/*GPIO function*/





extern void * mycall_ptr;	

static long set_dir_pwx(int gpio,int is_input)
{
	void __iomem *reg = 0xfa04c134;
	u32 l;
	//reg += bank->regs->direction;
	l = readl_relaxed(reg);
	if (is_input)
		l |= BIT(gpio);
	else
		l &= ~(BIT(gpio));
	writel_relaxed(l, reg);
	//bank->context.oe = l;
	return 0;
}

extern void * mycall_ptr2;
static long set_value_pwx(unsigned offset, int enable)
{
	unsigned long phy = 0x481ae000 + 0x013c;
	void __iomem *reg = ioremap(phy,1);

	u32 gpio_bit = BIT(offset);
	u32 l;

	l = readl_relaxed(reg);
	if (enable)
		l |= gpio_bit;
	else
		l &= ~gpio_bit;
	writel_relaxed(l, reg);
	//bank->context.dataout = l;
	return 0;
}

/*
 * gpio driver register needs to be done before
 * machine_init functions access gpio APIs.
 * Hence omap_gpio_drv_reg() is a postcore_initcall.
 */
static int __init omap_gpio_drv_reg(void)
{
//lab 2 starts
    int i;
    printk(KERN_INFO "----------------------------px_int() for inserting the module---------------------------------\n");
    if (alloc_chrdev_region(&first, 0, max_regions_number, DEVICE_NAME) < 0)  //$cat /proc/devices
    {
        return -1;
    }
    if ((cl = class_create(THIS_MODULE, DEVICE_NAME)) == NULL)    //$ls /sys/class
    {
        unregister_chrdev_region(first, max_regions_number);
        return -1;
    }
    if (device_create(cl, NULL, first, NULL, DEVICE_NAME) == NULL) //$ls /dev/
    {
        class_destroy(cl);
        unregister_chrdev_region(first, max_regions_number);
        return -1;
    }
    cdev_init(&c_dev, &fops);
    if (cdev_add(&c_dev, first, max_regions_number) == -1)
    {
        device_destroy(cl, first);
        class_destroy(cl);
        unregister_chrdev_region(first, max_regions_number);
        return -1;
    }
    printk(KERN_INFO "Device registerd.\n");
    mem_region = kmalloc(max_regions_number * sizeof(struct mem_dev), GFP_KERNEL); //kmalloc returns the virtual(linear) address
    if (!mem_region) return- ENOMEM;
    memset(mem_region, 'z', sizeof(struct mem_dev)); //initialize
    for (i=0;i<len1;i++) {
        history[i]=kmalloc(50, GFP_KERNEL);
    }
    
 
    for (i=0;i<max_regions_number;i++){
           printk("Before set to 0 mem_region[%d].size = %ld",i,mem_region[i].size);
           mem_region[i].size = 0;
           mem_region[i].ID = i+1;
           mem_region[i].data = NULL;
           regions[2*i] = mem_region[i].ID;
     }

//lab 2 ends
    mycall_ptr = set_dir_pwx;
    mycall_ptr2 = set_value_pwx;
    return platform_driver_register(&omap_gpio_driver);
}


static void __exit omap_gpio_exit(void)
{
//lab 2 starts
    int i;
    printk(KERN_INFO "----------------------------px_clean() for removing the module---------------------------------\n");
    for (i=0;i<len1;i++) {
        kfree(history[i]);
    }
    num_h=0;
    for(i=0;i<max_regions_number;i++){
       regions[2*i+1]=0;
       if(mem_region[i].size !=0){
           mem_region[i].size=0;
           kfree(mem_region[i].data);
           //mem_region[i].data=NULL;
           printk("You forget to free Region%d before unloading the module. Freed region is Region%d\n",i+1,i+1);
       }
    }

  
    kfree(mem_region);

    cdev_del( &c_dev );
    device_destroy( cl, first );
    class_destroy( cl );    
    unregister_chrdev_region( first, max_regions_number);
    printk(KERN_ALERT "Device unregistered\n");
//lab 2 ends
    platform_driver_unregister(&omap_gpio_driver);
}



//lab2 starts
/* 
 * Called when a process tries to open the device file, like
 * "cat /dev/mycharfile"
 */

static int device_open(struct inode *inode, struct file *file)
{
    
    struct mem_dev *dev;
    int num;
    printk(KERN_INFO "----------------------------device_open() for opening the file ---------------------------------\n");
    try_module_get(THIS_MODULE);
    num = MINOR(inode->i_rdev);
    if (num >= max_regions_number) return -ENODEV;
    dev = &mem_region[num];
    file->private_data = dev;
    return 0;
}

/* 
 * Called when a process closes the device file.
 */
static int device_release(struct inode *inode, struct file *file)
{
    int i;
    printk(KERN_INFO "----------------------------device_release() for closing the file---------------------------------\n");
    for(i=0;i<max_regions_number;i++){
       regions[2*i+1]=0;
       if(mem_region[i].size !=0){
           mem_region[i].size=0;
           kfree(mem_region[i].data);
           //mem_region[i].data=NULL;
           printk("You forget to free Region%d before closing the file. Freed region is Region%d\n",i+1,i+1);

       }
    }
    
    //mem_region=NULL;
    ID_active=0;
    allocated=0;
    region_count=0;
    module_put(THIS_MODULE);// if you lost this one, you can't use rmmod to remove the module

    return 0;
}


static inline void init_perfcounters (int32_t do_reset, int32_t enable_divider)
{
    // in general enable all counters (including cycle counter)
    int32_t value = 1;

    // peform reset:
    if (do_reset)
    {
    value |= 2;     // reset all counters to zero.
    value |= 4;     // reset cycle counter to zero.
    }

    if (enable_divider)
    value |= 8;     // enable "by 64" divider for CCNT.

    value |= 16;

    // program the performance-counter control-register:
    asm volatile ("MCR p15, 0, %0, c9, c12, 0\t\n" :: "r"(value));

    // enable all counters:
    asm volatile ("MCR p15, 0, %0, c9, c12, 1\t\n" :: "r"(0x8000000f));

    // clear overflows:
    asm volatile ("MCR p15, 0, %0, c9, c12, 3\t\n" :: "r"(0x8000000f));
}

int get_cyclecount (bool A){
    unsigned int value, overhead, t, i;
    //printk("In userspace the get_perf_counter system call is called\n");
    /* enable user-mode access to the performance counter*/
	if(A==true)
	{
    asm ("MCR p15, 0, %0, C9, C14, 0\n\t" :: "r"(1));
    /* disable counter overflow interrupts (just in case)*/
    asm ("MCR p15, 0, %0, C9, C14, 2\n\t" :: "r"(0x8000000f));
	}
	init_perfcounters (0, 1);// return value is cycles/64

    asm volatile ("MRC p15, 0, %0, c9, c13, 0\t\n": "=r"(value));
    return value;

}



static irq_handler_t px5_irq_handler_1(unsigned int irq, void *dev_id, struct pt_regs *regs){
   end = get_cyclecount();
   //printk(KERN_INFO "GPIO_TEST: Interrupt! (the saved counter value is %d)\n", t_end);
   set_dir_pwx(17, 0);
   set_value_pwx(17, 1);
   return (irq_handler_t) IRQ_HANDLED;      // Announce that the IRQ has been handled correctly
}
asmlinkage long lab4_part2(int mode, int gpio)
{       //printk("In userspace the syscall sys_lab4_part2 is called\n");
	if (mode == 0){ //capacitance measurement
		if (!gpio_is_valid(gpio)){
      			printk(KERN_INFO "GPIO_TEST: invalid GPIO\n");
      			return -ENODEV;
		}
		gpio_request(49, "sysfs");
                gpio_export(49, true);
		
		//request an interrupt line
		
                start = get_cyclecount(1);
                set_dir_pwx(17, 0);
                set_value_pwx(17,1);
                //gpio_set_debounce(gpio, 200); 
                //return 0;

		//gpio_direction_output(gpio,1);
		//gpio_direction_input(gpio);
		//set_dir_self(17,1);      //set as output
		//set_value_self(17,1);     //set as high
		//printk(KERN_INFO "GPIO_TEST: The input state is currently: %d\n",gpio_get_value(gpio));
	}
        else if (mode ==1){
                int suc_or_not;
                irqNumber = gpio_to_irq(49);
                //printk(KERN_INFO"GPIO_TEST: The gpio is mapped to IRQ: %d\n", irqNumber);
		suc_or_not = request_irq(irqNumber,     // result = 0 means success
			     	    (irq_handler_t) px5_irq_handler_1,
			     	    IRQF_TRIGGER_LOW,
			     	    "ELEC553_RL59_gpio_handler_1",
			     	    NULL);
                //enable_irq(irqNumber);
                set_dir_pwx(17, 1);
                if (suc_or_not != 0)printk("There is something wrong with the IRQ");
		//printk(KERN_INFO"GPIO_TEST: The interrupt request result is: %d\n", suc_or_not);
                return 0;
        }
	else if (mode == 2) 
	{
		free_irq(irqNumber, NULL);     //trying to free already-fred IRQ
                gpio_unexport(49);
		gpio_free(49);
		printk(KERN_INFO "GPIO_TEST: free gpio & irq\n");
                printk("The time from up to down is %d couner cycles\n",t_end-t_start);
                return end;
	}
        else if (mode == 3){//return the time measured
               	free_irq(irqNumber, NULL);     //trying to free already-fred IRQ
                gpio_unexport(49);
		gpio_free(49);
		//printk(KERN_INFO "GPIO_TEST: free gpio & irq\n");
                //printk("The time from up to down is %d couner cycles\n",t_end-t_start);
                return end-start;
        }
}


static long device_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
    int err = 0;
    long ret = 0;
    int i;
    int old;
    int ID_to_free;
    long secs;
    int threshold;

    int untouched_count = 0;
    int touched_status = 0;// 0 for not touched, 1 for touched
    // test if the cmd is a effective ioctl cmd
    if (_IOC_TYPE(cmd) != MEMDEV_IOC_MAGIC) {
        printk("_IOC_TYPE(cmd) != MEMDEV_IOC_MAGIC\n");
        return -EINVAL;
    }
    if (_IOC_NR(cmd) > MEMDEV_IOC_MAXNR) {
        printk("_IOC_NR(cmd) > MEMDEV_IOC_MAXNR\n"); 
        return -EINVAL;
    }
    //test if the parameters can be accessed
    if (_IOC_DIR(cmd) & _IOC_READ)
        err = !access_ok(VERIFY_WRITE, (void *)arg, _IOC_SIZE(cmd));
    else if (_IOC_DIR(cmd) & _IOC_WRITE)
        err = !access_ok(VERIFY_READ, (void *)arg, _IOC_SIZE(cmd));
    if (err){
        printk("!access_ok(VERIFY_READ, (void *)arg, _IOC_SIZE(cmd)\n");
        return -EFAULT;
    }
    //options
    switch(cmd) {
      case DELAY_SECONDS:
        ret=__get_user(secs,(int *)arg);// delay arg(defined in userspace) seconds without sleeping
        mdelay(1000*secs);
      case MEMDEV_IOCPRINT:   // print a string
      	printk("<--- CMD MEMDEV_IOCPRINT Done--->\n\n");
        break; 
      case MEMDEV_IOCGETDATA: // arg(defined in userspace)=test_ioarg 
        ret = __put_user(ID_active, (int *)arg);
        break;
      case MEMDEV_IOCSETDATA: // test_ioarg= arg(defined in userspace)
        ret = __get_user(test_ioarg, (int *)arg);
        printk("<--- In Kernel MEMDEV_IOCSETDATA test_ioarg = %d --->\n\n",test_ioarg);
        break;
      case MYMEM_IOCTL_ALLOC: // allocate arg(defined in userspace) bytes as a new memory region
        __get_user(current_region_size,(int *)arg);
        if(allocated + current_region_size > max_memory) {
             printk("No enough space to allocate %ld bytes",current_region_size);
             ret = -ENOMEM;
             break;
        }
        if(region_count == max_regions_number) return -EPERM;
        if(current_region_size < 64) 
             return -EINVAL;    //When I try kmalloc(8 bytes) or kmalloc(10 bytes), linux virtual machine stopped for memory overwrite 
        for (i=0 ;i<max_regions_number; i++){ //find a free region to allocate
           if (mem_region[i].size==0)break;
        }
        if(region_count==0) ID_active=1;//initial active region is Region1
        mem_region[i].data = kmalloc(current_region_size, GFP_KERNEL);
        memset(mem_region[i].data, 'a'+i, current_region_size);//initialize the new memory with the region ID
        mem_region[i].size=current_region_size;
        
        region_count += 1;
        allocated += current_region_size;
        regions[2*i+1] = mem_region[i].size; 
        
        ret=region_count;

        
        sprintf(history[num_h],"Allocate %ld bytes to Region%d\n",mem_region[i].size,mem_region[i].ID);
        num_h+=1;

        printk("Allocate %ld bytes of memory to Region%d\n",mem_region[i].size,mem_region[i].ID);
        break;
      case MYMEM_IOCTL_FREE:   //the ID of the region to be free = arg(defined in userspace)
        __get_user(ID_to_free,(int *)arg);
        if(ID_to_free <= 0 || ID_to_free > max_regions_number) return -EINVAL;
        if(ID_to_free == ID_active){
            printk("Region%d is active and it can't be freed\n",ID_to_free);
            return -EINVAL;
        }
        if(mem_region[ID_to_free-1].size==0){
            printk("Region%d is already freed\n",ID_to_free);
            ret= ID_to_free;
            break;
        }
        region_count -=1;
        allocated -=mem_region[ID_to_free-1].size;
        regions[2*ID_to_free-1]=0;

        kfree(mem_region[ID_to_free-1].data);
        mem_region[ID_to_free-1].data=NULL;
        mem_region[ID_to_free-1].size=0;

        ret=ID_to_free;

        sprintf(history[num_h],"Region%d is freed\n",ID_to_free);
        num_h+=1;

        printk("Region%d is freed\n",ID_to_free);
        break;
      case MYMEM_IOCTL_SETREGION:  //the ID of the region to be set as active region = arg(defined in userspace)
        old=ID_active;
        __get_user(ID_active,(int *)arg);
        if(ID_active <= 0 || ID_active > max_regions_number) return -EINVAL;
        if (mem_region[ID_active-1].size==0){
            printk("Regoion%d does not exist\n",ID_active);
            ID_active=old;
            return -EINVAL;
        }
        filp->f_pos=0;
        ret= ID_active;
        printk("Set active region to Region%d\n",ID_active);

        sprintf(history[num_h],"Set active region to Region%d\n",ID_active);
        num_h+=1;

        break;
      case TOUCH_SENSOR:
        touched_status = 0;
        untouched_count = 0;
        __get_user(threshold,(int *)arg);
        //time_h_to_l_2 = threshold;
        while(1){
             lab4_part2(0, 49);
             lab4_part2(1, 49);
             //time_h_to_l_1 = time_h_to_l_2;
             //time_h_to_l_2 = lab4_part2(3, 49);
             time_h_to_l = lab4_part2(3, 49);
             //printk("The time from high to low is %d\n",time_h_to_l);
             if(time_h_to_l< threshold) printk("touched\n");
             else if(time_h_to_l> threshold) printk("released\n");

        }
        break;
      default:  
        return -EINVAL;
    }
    return ret;

}

/* 
 * Called when a process, which already opened the dev file, attempts to
 * read from it.
 */

static ssize_t device_read(struct file *filp, char __user *buf, size_t size, loff_t *ppos)
{
   
   unsigned long p =  *ppos;        //the offset from the current pointer, *ppos is the same as filp->pos
   int ret = 0;
   int buffer_size;    
   //if (size != 1) return -EINVAL;
   if (p >= mem_region[ID_active-1].size) return -EINVAL;
   buffer_size=size;
   //printk(KERN_INFO "Entering device_read\n");
   //printk("In the device_read function, the value of *ppos is %ld\n",p);
   //printk("In the device_read_function, the value of filp->f_pos is %lld\n",filp->f_pos);
   if (buffer_size > mem_region[ID_active-1].size - p) buffer_size = mem_region[ID_active-1].size - p;
   if (copy_to_user(buf, mem_region[ID_active-1].data + p, buffer_size))
   {
     ret =  - EFAULT;
   }
   else
   {
      *ppos += buffer_size;
      ret = ID_active;
      //printk(KERN_INFO "Read %d byte(s) from %ld in Region%d\n", buffer_size, p, ID_active);
   }

   return ret;
}

static ssize_t device_write(struct file *filp, const char __user *buf, size_t size, loff_t *ppos)
{
        unsigned long p = *ppos;
	int buffer_size;
	int ret = 0;
        //if (size != 1) return -EINVAL;
	if (p >= mem_region[ID_active-1].size) return - EFAULT;
        buffer_size=size;
	//printk("Entering the device_write \n");
        //printk("In the device_write function, the value of *ppos is %ld\n",p);
        //printk("In the device_write_function, the value of filp->f_pos is %lld\n",filp->f_pos);
	if (buffer_size > mem_region[ID_active-1].size - p) buffer_size = mem_region[ID_active-1].size - p;
	if (copy_from_user(mem_region[ID_active-1].data + p, buf, buffer_size)) ret = - EFAULT;
        else
	{
		*ppos += buffer_size;
		ret = buffer_size;
		//printk(KERN_INFO "Write %d bytes(s) from %ld in Region%d\n", buffer_size, p, ID_active);
	}
	return ret;
}

static loff_t device_llseek(struct file *filp, loff_t offset, int whence)  
{   
    loff_t newpos;
    switch(whence) {  
      case 0: //SEEK_SET, from the head of the file 
        newpos = offset ;
        break;  
      case 1: //SEEK_CUR, from the current pointer   
        newpos = filp->f_pos + offset; 
        break;  
      case 2: // SEEK_END, from the tail of the file  
        newpos = mem_region[ID_active-1].size -1 + offset;  
        break;  
      default: // can't happen  
        return -EINVAL;  
    }
    filp->f_pos = newpos; 

    if (newpos < 0 || newpos >= mem_region[ID_active-1].size){
        return -EINVAL;
    }
      
    return newpos;  
} 


//lab 2 ends

static int myset(const char *, const struct kernel_param *);
static int myget(char *, const struct kernel_param *);
const struct kernel_param_ops myops = 
{
    .set = &myset,                         // Use my setter to get the  keyborad-input string, judge if it is <int> or not,
                                           //   if it is <int>, double it, and set (using<echo>) the value of the parameter to it.
                                           //   if it is not <int>, throw an error   
    .get = &param_get_int,                         // Use my getter to get (using <cat>) the value of the parameter and send it to the buffer for 
                                           // screenprint, and print something into the kern.log
};
static int start_monitor=0;       // default initial value, can be changed while using <insmod>
module_param_cb(start_monitor,    //filename
    &myops,                   //user-defined kernel paremeters operations, defined in a <kernel_param_ops> struct called myops below
    &start_monitor,               //pointer to variable, contained parameter's value 
    S_IRUGO | S_IWUSR         //permissions on file, on this setting, you can only use <echo> to write when you use <sudo su> to become a root user
);




static int myset(const char *val, const struct kernel_param *kp)
{
    int* pvalue = kp->arg;            // If not define <int* pvalue> and use <kp->arg> instead, there will be errors
    int res = param_set_int(val, kp); //Default <param_get_int>: read the keyborad input to string <var>,
                                      //         if <var>is integer, *(kp->arg)=string_to_int(var)
                                      //         if <var> is not integer,throwerrors
    int value = *pvalue;                                                
    if( res==0)
    {
        if(value == 1) {
              lab4_part2(0, 49);
              lab4_part2(1, 49);
              time_h_to_l = lab4_part2(3, 49);
              if (time_h_to_l < 0) touched_or_not =1;
              else touched_or_not =0;
        }
    }
    return res;
}



postcore_initcall(omap_gpio_drv_reg);
module_exit(omap_gpio_exit);
MODULE_DESCRIPTION("omap gpio driver");
MODULE_ALIAS("platform:gpio-omap");
MODULE_LICENSE("GPL v2");


