import Adafruit_BBIO.ADC as ADC
import os
threshold = 0.5
ADC.setup()
#os.system("export PATH=~/.local/bin:$PATH")
#os.system("source ~/.profile")


v = ADC.read("P9_40")
if v < threshold:
    print("Pin touched")
    os.system("aws dynamodb put-item --table-name  ELEC553_LAB5 --item \'{\"Artist\": {\"S\": \"No One You Know\"}, \"SongTitle\": {\"S\": \"Call Me Today\"}, \"AlbumTitle\": {\"S\": \"Somewhat Famous_"+str(2)+"\"}}\' --return-consumed-capacity TOTAL")
else:
    print ("Pin released")
