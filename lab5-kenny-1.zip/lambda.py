from email.mime.text import MIMEText
from email.header import Header
from smtplib import SMTP_SSL


def lambda_handler(event, context):
    # rice server
    host_server = 'smtp.mail.rice.edu'
    # rce NetID
    sender_qq = 'rl59'
    # password
    pwd = 'airjordan23B'
    # sender
    sender_qq_mail = 'rl59@rice.edu'
    # receiver
    receiver = 'liverpool_lr@yahoo.com'

    # content
    mail_content = 'Warning, the table has been changed'
    # title
    mail_title = 'Notification from AWS'

    # ssl
    smtp = SMTP_SSL(host_server)

    smtp.set_debuglevel(1)
    smtp.ehlo(host_server)
    smtp.login(sender_qq, pwd)

    msg = MIMEText(mail_content, "plain", 'utf-8')
    msg["Subject"] = Header(mail_title, 'utf-8')
    msg["From"] = sender_qq_mail
    msg["To"] = receiver
    smtp.sendmail(sender_qq_mail, receiver, msg.as_string())
    smtp.quit()