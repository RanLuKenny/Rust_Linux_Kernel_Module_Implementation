#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<linux/kernel.h>
#include<sys/ioctl.h>
int main(){
	char *cp;
	char buffer[10];
while(1){
	system("echo 1 > /sys/module/gpio_omap/parameters/start_monitor");	
	FILE *A = fopen("cat /sys/module/gpio_omap/parameters/touched_or_not","r");
	
	cp = fgets(buffer,10,A);

	long ret = atol(buffer);
	if(ret == 0)	printf("untouched\n");
	else if(ret == 1)
	{ 
			printf("touched\n") ;
			system("aws dynamodb put-item --table-name  ELEC553_LAB5 --item \'{\"Artist\": {\"S\": \"No One You Know\"}, \"SongTitle\": {\"S\": \"Call Me Today\"}, \"AlbumTitle\": {\"S\": \"Somewhat Famous_2" "\"}}\' --return-consumed-capacity TOTAL");  
	}	
	pclose(A);
}
}
